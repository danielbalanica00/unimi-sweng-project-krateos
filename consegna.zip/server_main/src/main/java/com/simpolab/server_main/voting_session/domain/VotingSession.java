package com.simpolab.server_main.voting_session.domain;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import java.time.Instant;
import java.util.Date;
import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
<<<<<<< Updated upstream
=======

>>>>>>> Stashed changes
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
@EqualsAndHashCode(of = { "id" })
@Builder(toBuilder = true)
@Slf4j
public class VotingSession {

  public enum Type {
    ORDINAL,
    CATEGORIC,
    CATEGORIC_WITH_PREFERENCES,
    REFERENDUM,
  }

  public enum State {
    INACTIVE,
    ACTIVE,
    CANCELLED,
    ENDED,
    INVALID,
  }

  @Min(0)
  @JsonProperty(access = JsonProperty.Access.READ_ONLY)
  @NonNull
  private Long id;

  @NotBlank
  private String name;

  @Future
  private Date endsOn;

  private boolean needAbsoluteMajority = false;
  private boolean hasQuorum = false;

  @NonNull
  private Type type;

  private State state = State.INACTIVE;

  @JsonIgnore
  public Date getEndsOn() {
    return endsOn;
  }

  @JsonSetter("endsOn")
  public void setEndsOnFromEpoch(long epochTime) {
    this.endsOn = Date.from(Instant.ofEpochSecond(epochTime));
  }

  @JsonGetter("endsOn")
  public long getUnixTime() {
    return endsOn.getTime() / 1000;
  }

  @JsonIgnore
  public boolean isActive() {
    return state == State.ACTIVE;
  }
}
