package com.simpolab.server_main.auth.services;

public interface UserService {}
