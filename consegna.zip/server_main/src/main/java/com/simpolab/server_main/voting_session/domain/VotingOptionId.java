package com.simpolab.server_main.voting_session.domain;

public record VotingOptionId(long id, Long parentId) {}
