#!/usr/bin/env bash
set -euo pipefail

# Install the runtime and package manager.
sudo apt install lua5.3 liblua5.3-dev luarocks
