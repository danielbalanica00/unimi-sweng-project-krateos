﻿using System;

namespace dotnet_hooks_sln_repo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello from dotnet!");
        }
    }
}
