package PreCommitHello;

use strict;
use warnings;

our $VERSION = "0.1.0";

sub hello {
    print "Hello from perl-commit Perl!\n";
}

1;
