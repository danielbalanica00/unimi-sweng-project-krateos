// swift-tools-version:5.0
import PackageDescription

let package = Package(
    name: "swift_hooks_repo",
    targets: [.target(name: "swift_hooks_repo")]
)
