stopifnot(
    packageVersion('rprojroot') == '1.0',
    packageVersion('gli.clu') == '0.0.0.9000'
)
cat("Hello, World, from R!\n")
