﻿using System;

namespace proj1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello from dotnet!\n");
        }
    }
}
